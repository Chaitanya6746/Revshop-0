package model;

public class Order {

}
